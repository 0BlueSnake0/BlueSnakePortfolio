function GetExpirience(nodeIndex)
{
    $("#click-hint").css("display","none");
    $("#expirience-details .expirience" + nodeIndex).css("display","none");
    $("#expirience-details #exp-" + nodeIndex).css("display","block");
}
