var leftParticleDurationBorder=3, rightParticleDurationBorder=15;
var leftSizeBorder=4, rightSizeBorder=12;

var particleAnimations = [
    "particleMoveLeft", "particleMoveLeft", "particleMoveLeft", "particleMoveLeft",
    "particleMoveRight", "particleMoveRight", "particleMoveRight", "particleMoveRight",
    "particleMoveTop", "particleMoveTop", "particleMoveTop", "particleMoveTop",
    "particleMoveBottom", "particleMoveBottom", "particleMoveBottom", "particleMoveBottom",

    "particleMoveLeftTop","particleMoveLeftTop","particleMoveLeftTop","particleMoveLeftTop",
    "particleMoveRightTop","particleMoveRightTop","particleMoveRightTop","particleMoveRightTop",
    "particleMoveLeftBottom","particleMoveLeftBottom","particleMoveLeftBottom","particleMoveLeftBottom",
    "particleMoveRightBottom","particleMoveRightBottom","particleMoveRightBottom","particleMoveRightBottom",
];
